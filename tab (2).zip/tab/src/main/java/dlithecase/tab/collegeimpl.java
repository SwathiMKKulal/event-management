package dlithecase.tab;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class collegeimpl {
	
	SessionFactory factory=null;
	Session session=null;
	
	public void end()
	{
	}
public void create()
{
	SessionFactory factory=new Configuration().configure().buildSessionFactory();
    Session session=factory.openSession();
    session.beginTransaction();
    
    stud s1=new stud(1,"mani","bangalore");
    stud s2=new stud(2,"ram","bengal");
    
    session.save(s1);
    //session.save(s2);
	session.getTransaction().commit();
	session.close();
    //stud s2=new stud("Mahesh1","2", "4","mlore");
}

public void update()
{
	SessionFactory factory=new Configuration().configure().buildSessionFactory();
    Session session=factory.openSession();
    session.beginTransaction();
    
	stud t=(stud)session.get(stud.class,2);
	
    t.setAddress("hii");// update
    session.update(t);

	session.getTransaction().commit();
	session.close();
}
public void delete()
{
	SessionFactory factory=new Configuration().configure().buildSessionFactory();
    Session session=factory.openSession();
    session.beginTransaction();
	stud s3=(stud)session.get(stud.class, 1);// read
    session.delete(s3);
    session.getTransaction().commit();
	session.close();
}
public void list()
{
	 
	 Query qry=session.createQuery("select name from stud");
     List<String> pool=qry.list();
     System.out.println(pool);
     
     qry=session.createQuery("from stud where name like '%mani'");
     List<stud> pools=qry.list();
     for(stud sid:pools) {System.out.println(sid.getName()+" "+sid.getAddress());}
     
     System.out.println("All ");
     qry=session.createQuery("from stud");
     pools=qry.list();
     for(stud sid:pools) {System.out.println(sid);}
     
     Scanner scan=new Scanner(System.in);
     int id1=scan.nextInt();int id2=scan.nextInt();
     
     System.out.println("Dynamic query ");
     qry=session.createQuery("from Siddha where docId between ?1 and ?2");
     qry.setInteger(1, id1);qry.setInteger(2, id2);
     pools=qry.list();
     for(stud sid:pools) {System.out.println(sid);}
     
     session.getTransaction().commit();
     session.close();
}
public void read()
{
	stud temp=(stud)session.get(stud.class, 1);// read
    //System.out.println(temp);
}
}
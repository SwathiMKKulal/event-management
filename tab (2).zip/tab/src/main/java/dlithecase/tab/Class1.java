package dlithecase.tab;

public interface Class1 {
	
	public void create();
	public void read();
	public void update();
	public void delete();
	public void list();

}

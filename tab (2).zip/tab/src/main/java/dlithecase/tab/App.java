package dlithecase.tab;


/**
 * Hello world!
 *
 */
public class App 
{
		
    public static void main( String[] args)
    {
        System.out.println( "welcome" );
        collegeimpl c=new collegeimpl();
        //c.update();
        //c.list();
        c.create();
        c.end();
       // c.delete();
       
    
      
    }
}

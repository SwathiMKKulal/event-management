package j.spring.boot1;

public class student {
	
	private String sname;
	private int usn;
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public int getUsn() {
		return usn;
	}
	public void setUsn(int usn) {
		this.usn = usn;
	}
	public student() {}
	public student(String sname, int usn) {
		super();
		this.sname = sname;
		this.usn = usn;
	}
	@Override
	public String toString() {
		return "student [sname=" + sname + ", usn=" + usn + "]";
	}
	
	

}

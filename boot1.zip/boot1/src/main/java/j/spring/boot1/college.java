package j.spring.boot1;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class college implements InitializingBean, DisposableBean {
	
	private student std1,std2,std3;

	public student getStd1() {
		return std1;
	}

	public void setStd1(student std1) {
		this.std1 = std1;
	}

	public student getStd2() {
		return std2;
	}

	public void setStd2(student std2) {
		this.std2 = std2;
	}

	public student getStd3() {
		return std3;
	}

	public void setStd3(student std3) {
		this.std3 = std3;
	}

	@Override
	public String toString() {
		return "college [std1=" + std1.toString() + ", std2=" + std2.toString() + ", std3=" + std3.toString() + "]";
	}

	public college(student std1, student std2, student std3) {
		super();
		this.std1 = std1;
		this.std2 = std2;
		this.std3 = std3;
	}
	public college() {}

	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		
	}

	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		
	}

	

}

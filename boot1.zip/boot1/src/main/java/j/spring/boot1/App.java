package j.spring.boot1;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import j.spring.boot1.college;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //System.out.println( "Hello World!" );
       AbstractApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
        context.registerShutdownHook();
        /*student st=(student)context.getBean("s1");
          System.out.println(st);
     st=( student)context.getBean("s2");
       System.out.println(st);
      st=(student)context.getBean("s3");
       System.out.println(st);*/
      college col=(college)context.getBean("col");
       System.out.println(col);
    }
}
